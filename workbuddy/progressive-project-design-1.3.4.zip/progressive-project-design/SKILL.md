---
name: progressive-project-design
display_name: 渐进式项目设计
display_name_en: Progressive Project Design
description: "Use when initializing or reviewing a project, aligning requirements, planning functional slices, diagnosing defects, or calibrating project documents against implementation."
description_zh: "当用户需要初始化或梳理项目、确认需求、规划功能切片、诊断并修复缺陷，或校准项目文档与实现时使用。"
description_en: "Use when initializing or reviewing a project, aligning requirements, planning functional slices, diagnosing defects, or calibrating project documents against implementation."
version: 1.3.4
author: "xiaoda001"
examples_zh:
  - "为这个新项目确认需求、设计架构并形成 spec。"
  - "根据已确认的 spec 拆分垂直功能切片，并为第一个切片规划验收场景。"
  - "审查当前实现和测试证据，校准受影响的项目文档。"
examples_en:
  - "Clarify requirements, define the architecture, and write the spec for this project."
  - "Break the accepted spec into vertical slices and plan acceptance scenarios for the first slice."
  - "Review the implementation and test evidence, then calibrate the affected project documents."
---

# Progressive Project Design

Always respond in the user's language. This skill treats documentation as an output of decisions, not as Big Design Up Front.

## Operating principles

- Design only what the current decision or vertical slice needs.
- Use the smallest runnable, verifiable end-to-end slice as the planning unit.
- Keep uninvolved modules at D0; do not pre-design later scope.
- Stop after the current stage's artifact. Continue only when a new trigger exists.
- Treat existing code as the source of truth during reverse calibration.
- Treat agent-enabled delivery as an end-to-end workflow: capture intent, review a bounded plan, verify outputs, enforce risk-appropriate human decisions, and feed operational evidence back into planning.
- Keep the workflow portable across coding agents. Define shared artifacts, decisions, and checks independently of any agent's product-specific files or features; adapt only the execution mechanism to the active agent's documented capabilities.
- Confirm requirements through an iterative question-and-validation loop. Make material decision branches visible, update the shared understanding after each answer, and do not treat silence as approval.
- When initializing a new project or when the user explicitly asks to define development standards, find candidate rules for the confirmed technology stack in [PatrickJS/awesome-cursorrules](https://github.com/PatrickJS/awesome-cursorrules). Present suitable options and their scope first, then download the selected rules only after the user chooses. Review versions, file applicability, and conflicts with the project before adapting them. Do not bulk-download or enable unreviewed rules by default.
- Treat tests as contract evidence, not a green-check target: derive expectations from the confirmed spec, require meaningful assertions and risk-relevant boundaries, and never invent or misstate execution results.
- Calibrate only affected documents; separate observed implementation facts from accepted intent, expose unresolved mismatches, and withhold D4 when applicable verification is pending.
- Keep generated `.ppd/` project documentation local. Ensure the project-root `.gitignore` excludes `.ppd/`, preserving existing rules or creating the file when needed. Do not stage, commit, or upload `.ppd/`. If `.ppd/` files are already tracked, report that ignore rules do not untrack them; do not change the Git index without an explicit request.

## Status model

| Dimension | Values | Meaning |
|---|---|---|
| Documentation maturity | D0 → D1 → D2 → D3 → D4 | unregistered → draft → approved → implementing → calibrated |
| Design depth | L0 → L1 → L2 | boundary → current-slice detail → full relevant detail |

Use `D4-reverse-engineered` for documentation extracted from implemented code until its scope and behavior have been checked. Use L2 only when the current work requires edge cases, failure handling, performance, or similar constraints.

## Progressive disclosure and routing

Read only the reference needed for the current task. Do not load every reference by default.
When loading a supporting file, use WorkBuddy's reference syntax, such as `@references/requirements-confirmation.md`.

| User intent or project state | Read next |
|---|---|
| First activation or missing `.ppd/` | @references/initialization.md, then @references/directory-structure.md |
| Existing project without reliable `.ppd/` | @references/migration.md, @references/existing-project.md, then @references/directory-structure.md |
| Confirming requirements | @references/requirements-confirmation.md |
| Turning aligned requirements into architecture, a feature spec, and functional slices | @references/solution-design-and-spec.md, then @references/slice-planning.md |
| Planning or starting a slice | @references/slice-planning.md, @references/verification-and-backtest.md |
| Implementing a slice | @references/implementation-log.md |
| Reviewing or accepting an implementation | @references/review-and-acceptance.md |
| Diagnosing and fixing a reported defect | @references/targeted-repair.md |
| Asking what to do next | @references/task-navigation.md |
| Designing an AI-agent delivery workflow, evaluating agent behavior, or closing the production-feedback loop | @references/agent-delivery-loop.md, then load only the relevant slice, verification, review, or calibration reference |
| Slice completed or docs drifted | @references/calibration.md |
| Asking for project state | @references/project-snapshot.md |
| Creating or updating a `.ppd/` artifact | Read only the matching section in @references/templates.md; for structure or verification artifacts also read @references/structure-and-verification-templates.md |

## First activation decision tree

1. Check whether the project root contains `.ppd/`.
2. Ensure the project-root `.gitignore` excludes `.ppd/`, preserving existing ignore rules or creating the file when needed. If `.ppd/` files are already tracked, report this because ignore rules do not untrack existing files; do not change the Git index without an explicit request.
3. If it is a new project, create only the skeleton and stop.
4. If code already exists and `.ppd/` is missing or stale, perform one reverse-analysis pass and create clearly marked draft/reverse-engineered artifacts; do not redesign implemented behavior.
5. If `.ppd/` is healthy, read the project snapshot and continue at the current stage; do not repeat initialization. After identifying likely affected modules, check the linked standalone-repair index for entries matching the module or behavior. Do this for new features, requirement changes, and defects; read only matching notes and verify historical findings against current code.

## Task framing and gap scan

Before design or implementation, help the user clarify the task boundary. State the task size and scale the workflow accordingly:

- **Targeted change:** a small repair or copy change within an existing flow; inspect the local context and use a concise inline spec when useful.
- **Bounded feature:** an end-to-end user flow that fits existing system boundaries; inspect the flow and related interfaces before defining a slice.
- **Cross-cutting or new subsystem:** introduces a system boundary, changes shared interfaces, or spans independent modules; first identify relationships, dependencies, and delivery order.

Inspect relevant code, project documents, and the request. Scan only areas that could affect this task: users, roles, permissions and workflow; UI, services/APIs, callers, data models and state; data lifecycle, history/audit, concurrency and consistency; notifications, integrations and background work; failure, recovery and regressions; compatibility and migrations; deployment, configuration, monitoring, backups and release constraints; acceptance and evidence.

Present a compact task framing: desired outcome, proposed scope, likely affected modules/interfaces, non-goals, open material decisions, success criteria, and important omissions or risks. For broad feature requests, surface the highest-impact relevant gaps before planning or implementation instead of only promising to check later. Label each as confirmed impact, risk to verify, or optional scope, and explain why it matters. Separate evidence from inference and user decisions; do not expand scope just to complete a checklist.

Ask only about unresolved choices that can change scope, user-visible behavior, compatibility, or material risk. Explain trade-offs and recommend an option when evidence supports one. Ask dependent questions one at a time; independent questions may be grouped briefly. If a request spans independent subsystems, identify their dependencies and order before detailed feature questions. If discovery expands the impact beyond the initial classification, pause, explain the new modules/interfaces/risks, and reframe the options. Complexity may increase; do not downgrade the process to save time. Classification controls analysis depth, not extra approval or document ceremonies.

For new features or substantial changes, use this order after requirements align: define architecture boundaries, write and confirm the feature spec, identify high-level acceptance scenarios, decompose the spec into functional vertical slices, then plan and implement one slice at a time. Keep architecture at L0/L1 for unstarted scope; deepen only the active slice. Small fixes may use a concise inline spec and go directly to targeted repair.

The initial directory skeleton is:

```text
.ppd/
├── README.md
├── 01-overview/
├── 02-architecture/
├── 03-plan/
├── 04-progress/
└── 05-modules/
```

Do not create future slice directories until the slice is registered in the roadmap.

## Required slice invariant

Before implementing a slice, record:

- a completion condition: what can run or be demonstrated;
- applicable verification cases: the main success path, a relevant boundary case, a failure/recovery case, and a regression case when prior behavior exists;
- planned unit-test coverage for new or changed behavior. Name the expected test file/case and command when known; if implementation details are not yet known, mark them as planned or `TBD` and finalize them during implementation.

Add or update unit tests for behavior changes, following repository conventions and covering changed logic plus relevant boundary and failure behavior. Derive test expectations from the confirmed contract, not solely from implementation. Assertions must detect meaningful regressions; do not weaken or skip checks just to obtain a passing run. If the behavior cannot reasonably be isolated in a unit test, use the most appropriate available test level and record why. Do not add a new test framework outside the slice's scope without justification. Read @references/verification-and-backtest.md for test-integrity checks.

After implementation, analyze the impact scope of code or behavior changes before verification. Identify changed units, interfaces, dependencies, existing callers, and prior behavior. For a change contained within one unit, run that unit's tests and relevant regressions. For cross-unit or interface changes, include affected dependents and the relevant module or package suite. Use the full repository suite when a shared/core contract affects multiple areas, or when no bounded suite provides meaningful coverage; if impact remains unclear after investigation, run the broadest bounded relevant suite and explain the choice. For documentation-only changes, do not run unit tests; use applicable documentation checks when available. For configuration-only changes, select tests according to the behavior the configuration can affect. Log the scope, selection rationale, commands, results, evidence, and gaps. If a test cannot be authored or run, record why, alternative verification, and remaining risk; never report an unrun test as passing.

For financial, time-series, recommendation, or model work, verification cases may be called backtests and must specify a fixed dataset, parameters, metrics, and reproducible execution command. For ordinary business software, use verification, acceptance, replay, or regression cases instead. Run unit tests selected from impact analysis when code behavior changes; documentation-only changes use applicable documentation checks instead.

After implementation, use the review and acceptance workflow when the task or risk calls for it. Review findings first and keep fixes separate unless they are within the authorized task. Map each requirement to an acceptance criterion, implementation location, evidence, and status. For a reported defect, use the targeted-repair workflow to establish a reproducer, validate a root-cause hypothesis, make the smallest justified change, and leave the result pending until verification evidence exists. Repairs within a slice belong in that slice's progress log. Create and index a standalone repair note only when its root cause, decision, behavior constraint, or verification lesson is worth reusing. For a later task, start from `.ppd/README.md`, read matching repair notes, and verify current code before relying on historical findings. Ask the user only when an unresolved choice changes scope, behavior, or another material project decision.

## Decision standard

Before writing any document, answer:

> Who will read it? When will they read it? What decision will they make after reading it?

If those answers are unclear, do not create the document yet.

## Agent portability

This Skill is for coding agents across products, including Codex, Claude Code, Trae, and others. Treat the workflow and project artifacts as the portable contract. Do not require a specific agent, model, configuration filename, plugin, tool protocol, or vendor feature. Before using an agent-specific capability, confirm it is available in the active environment and provide a tool-agnostic fallback when practical. Keep project policy and source-of-truth artifacts in the project or its established systems; agent-specific instructions may only adapt how the shared workflow is executed and must not redefine it.

## Relationship invariants

- `.ppd/README.md` is the single root-level navigation entry point; subordinate indexes, such as `04-progress/repairs/README.md`, must be linked from it.
- Module documents contain responsibility, interfaces, dependencies, code locations, and backlinks.
- Code links must use `path#line` and be updated during calibration.
- D4 claims require implementation evidence; a filename alone is not evidence.
- A calibration aligns only affected documents with accepted scope and evidence; it must not silently add scope, hide spec mismatches, or promote unverified behavior to D4.
