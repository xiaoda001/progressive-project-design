# Progressive Project Design

[Simplified Chinese](README.md) | [English](README.en.md) | [日本語](README.ja.md) | [한국어](README.ko.md)

一个面向 AI 编程代理的渐进式项目设计 Skill。它通过 Just-in-Time Design（按需设计）、垂直切片以及代码↔文档校准，让项目文档随着实现演进，同时避免 Big Design Up Front。

## 核心原则

> 文档是决策的产物，不是决策的起点。

- **按需设计**：只细化当前决策或当前切片需要的内容。
- **切片驱动**：以端到端可运行、可验证的最小闭环为设计单位。
- **及时停笔**：完成当前阶段产出后停止，不提前设计后续范围。
- **实现校准**：切片完成后，用代码、测试、配置和运行行为更新文档。
- **双向关系**：在模块文档中维护接口代码位置、依赖和反向链接。
- **证据化审查与验收**：将需求对应到验收标准、实现位置和验证证据；收到缺陷反馈时按定点修复流程处理。
- **本地保存项目文档**：在使用该 Skill 的项目 `.gitignore` 中忽略 `.ppd/`，不要暂存或提交它。

## 状态模型

| 维度 | 状态 |
|---|---|
| 文档成熟度 | `D0` 未登记 → `D1` 草稿 → `D2` 已批准 → `D3` 实现中 → `D4` 已校准 |
| 设计深度 | `L0` 边界 → `L1` 当前切片所需 → `L2` 完整细化 |

通常以 L1 开工；只有当前实现确实需要边界情况、异常处理、性能等约束时才进入 L2。

## 项目文档体系

Skill 使用 `.ppd/` 作为渐进式文档入口：

```text
.ppd/
├── README.md
├── 01-overview/
├── 02-architecture/
├── 03-plan/
├── 04-progress/
│   └── <slice>/
└── 05-modules/
```

首次使用时检查现有结构，只建立必要骨架。已有代码的项目采用逆向校准：从当前实现提取模块、接口、数据模型和依赖，再逐个切片补齐文档。

## 五阶段节奏

| 阶段 | 触发点 | 产出 |
|---|---|---|
| 骨架 | 项目初始化 | `.ppd/README.md` 和最小目录 |
| 需求 | 边界确认后 | 项目定位、范围、关键决策和非目标 |
| 切片启动 | 当前切片准备实现 | 当前切片涉及的技术决策（如有）、相关模块 L1、路线图登记 |
| 实现中 | 发生有意义的变更 | 影响范围、所选测试、执行命令与结果、决策原因和遗留事项；视风险进行审查与需求验收 |
| 校准 | 切片实现完成 | D3→D4、代码位置、偏差和反向链接 |

## 验证与测试

行为变更的切片需要在开发前定义主流程、适用的边界与失败/恢复场景、必要的回归用例，并为新增或变更行为计划单元测试。如果行为逻辑不适合单独进行单元测试，则使用最合适的测试层级并记录理由。实现后分析受影响的单元、接口、依赖和调用方，运行对应单元测试及相关回归测试；跨单元变更时扩大到受影响的模块或包。记录影响范围、测试选择理由、命令、结果和证据。测试无法编写或运行时，记录原因、替代验证和剩余风险。纯文档变更运行适用的文档检查，不要求单元测试。按风险选择代码审查，并用“需求—验收标准—实现位置—证据”追踪交付情况，详见[审查与验收](references/review-and-acceptance.md)；具体缺陷使用[定点修复流程](references/targeted-repair.md)，验证证据产生前保持待验证状态。详见[验证工作流](references/verification-and-backtest.md)。

## 适用场景

- 为新项目建立轻量、可演进的架构文档；
- 将已有项目迁移到渐进式设计，同时保留现有 README、ADR 和 RFC；
- 规划端到端垂直切片；
- 为行为变更补充单元测试，并按影响范围选择回归测试；
- 根据路线图、模块 L1 文档和代码确定下一项任务；
- 排查实现与文档之间的偏差；
- 在切片完成后生成回顾并校准模块文档。

## 安装

将以下 prompt 复制给你的 AI 编程代理：

```text
请从 https://github.com/xiaoda001/progressive-project-design 安装此 Skill
```

## 使用步骤

1. 在编程代理中打开要处理的项目。
2. 通过 `$progressive-project-design` 调用 Skill，说明任务以及项目是新建还是已有项目。
3. 查看当前阶段的产物。Skill 会检查 `.ppd/` 和项目现有证据，只处理当前需要的阶段。
4. 准备好继续时，再次调用 Skill 并说明下一项任务，例如规划切片、实现切片或校准文档。

示例：

```text
$progressive-project-design 检查这个项目的渐进式设计状态，并告诉我最小的下一步
$progressive-project-design 为这个新项目建立最小的 .ppd 文档骨架
$progressive-project-design 根据当前路线图规划下一个垂直切片
$progressive-project-design 审查当前切片，并将每项需求对应到验收证据
$progressive-project-design 定位这个缺陷的根因，只做最小修复并验证
$progressive-project-design 校准当前切片涉及的模块文档
```

Claude Code 使用斜杠形式，例如：

```text
/progressive-project-design 检查当前项目状态
```

## 仓库结构

```text
progressive-project-design/
├── SKILL.md
├── agents/
├── references/
├── README.md
├── README.en.md
├── README.zh.md
├── README.ja.md
└── README.ko.md
```

## 许可证

[MIT License](LICENSE)
